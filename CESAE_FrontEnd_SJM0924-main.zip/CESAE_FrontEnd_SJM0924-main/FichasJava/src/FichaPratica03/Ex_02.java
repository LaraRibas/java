package FichaPratica03;

public class Ex_02 {
    public static void main(String[] args) {

        // Declarar variáveis
        int contador = 2;

        // Imprimir os pares entre 1 e 400
        while (contador <= 400) {
            System.out.println(contador);
            contador = contador + 2;
        }

    }
}
