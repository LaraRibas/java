package FichaPratica03;

public class Ex_01 {
    public static void main(String[] args) {

        // Declarar variáveis
        int contador = 1;

        // Ciclo de 1 a 250
        while (contador <= 250) {
            System.out.println(contador);
            contador = contador + 1;
        }

    }
}
