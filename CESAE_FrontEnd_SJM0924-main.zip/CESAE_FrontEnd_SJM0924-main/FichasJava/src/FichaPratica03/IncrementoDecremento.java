package FichaPratica03;

public class IncrementoDecremento {
    public static void main(String[] args) {

        int num = 10;

        num++; // num = num + 1;
        num += 1; // num = num + 1;
        num += 5; // num =num + 5;

        num--; // num = num - 1;
        num -= 1; // num = num - 1;
        num -= 7; // num = num - 7;

        num *= 3; // num = num * 3;

        num /= 2; // num = num / 2;

        System.out.println(num);

        System.out.println(num);

    }
}
