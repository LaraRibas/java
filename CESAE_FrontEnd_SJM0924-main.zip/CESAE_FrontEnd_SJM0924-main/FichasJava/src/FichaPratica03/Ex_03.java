package FichaPratica03;

public class Ex_03 {
    public static void main(String[] args) {

        // Declarar variáveis
        int contador = 531;

        // Imprimir os pares entre 1 e 400
        while (contador <= 750) {
            System.out.println(contador);
            contador = contador + 2;
        }

    }
}
